# NOTIFY CONTROL PRO (com.kos.notifycontrol)

Native Android control center (Kotlin, Compose, Material 3, Hilt, DataStore).
Rule: no fake data. Unavailable -> "غير متاح"; needs permission -> "يتطلب إذناً".

## Status: Phases 1-5 (partial) written, NOT yet built or tested by the author
Phase 1: Settings (theme in DataStore), Navigation, AR/EN, dark/light.
Phase 2: real clock/date, battery (level, charging status, temperature if reported), internal storage (StatFs), device info (Build). Anything the system does not report shows "غير متاح".
Phase 3: system brightness slider (needs WRITE_SETTINGS grant; value always re-read from the system), display info + shortcut to system Display settings, volume per stream with the real min/max range (AudioManager), ringer mode, Do Not Disturb (needs notification policy access), shortcut to Sound settings.
Phase 4: Wi-Fi and Bluetooth state (broadcast-driven), active connection type, airplane mode state; toggles that Android blocks open the system panel/settings instead (Wi-Fi panel, Bluetooth enable dialog, airplane, internet, hotspot via network settings). Mobile data enabled-state and hotspot state are not readable through public APIs and show "غير متاح".
Phase 5 (partial): flashlight (CameraManager torch callback), calculator (exact decimal engine), timer (persisted end time + inexact alarm + notification), stopwatch, voice recorder (MediaRecorder, app-private storage, share/delete), shortcuts to camera / app settings / system settings. NOT implemented: screen recording (needs a MediaProjection foreground service), recent apps (no public API). Settings moved to a gear icon on the Dashboard to keep the bottom bar at five items.
Phase 5 r2: tri-state DND access, torch UNKNOWN state, RecordingStore (.part files), timer restore on app start. See CHANGES_phase5_r2.md.
Not started: phases 6-10.

## Toolchain
JDK 17, Gradle 8.11.1 (wrapper), AGP 8.9.1, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Hilt 2.52, Compose BOM 2024.12.01, compileSdk/targetSdk 36, minSdk 26.

## One-time wrapper setup
`gradle/wrapper/gradle-wrapper.jar` is a binary that could not be generated offline. Generate and commit it once:
`gradle wrapper --gradle-version 8.11.1` (any local Gradle >= 8.11.1), then `./gradlew testDebugUnitTest assembleDebug`.

## Release
Secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD, then run the "Android Release" workflow.
