# NotifyControlPro phase4-r2: change report

Status: NOT built and NOT run by the author (no Android SDK / Gradle / network in the authoring environment).
No test result is claimed. gradle-wrapper.jar is still missing and must be generated with
`gradle wrapper --gradle-version 8.11.1` on a machine with network access.

## Problems fixed
1. Bluetooth state refused on Android 12+ (SecurityException) was shown as a generic "unavailable" with no way forward.
   Now it is a distinct state PERMISSION_REQUIRED with an explanation and a "grant permission" button.
2. After the permission dialog, the real state is re-read from the system (denied: error + app-settings button).
   The "turn on" dialog is launched after a grant only if the re-read state is OFF.
3. SecurityException review of network, sound and display reads:
   - Network: Wi-Fi, Bluetooth, airplane, active-network reads are guarded. A failed/unreadable active network is
     ActiveTransport.UNKNOWN (new), never "no connection". registerDefaultNetworkCallback failures no longer crash the flow.
   - Sound: every read is guarded; a refused stream is omitted, a refused ringer/DND filter is unavailable. The DND switch is
     replaced by "unavailable" when the filter is unknown. setVolume now reads inside the try block.
   - Display: Settings.System reads and canWrite are guarded.
4. Test dispatcher setup: MainDispatcherRule now owns an explicit TestCoroutineScheduler. Analysis: it is applied before runTest, so
   runTest shares that scheduler. Two new tests (DispatcherSetupTest) assert this. Not executed.

## Files changed
- domain/model/NetworkModels.kt (ToggleState.PERMISSION_REQUIRED, ActiveTransport.UNKNOWN)
- data/system/SystemNetworkRepository.kt, SystemSoundRepository.kt, SystemDisplayRepository.kt
- features/network/NetworkViewModel.kt, NetworkScreen.kt, features/sound/SoundScreen.kt
- core/designsystem/Components.kt (SettingsIntents.appDetails)
- res/values/strings.xml, res/values-en/strings.xml (2 strings)
- test: MainDispatcherRule.kt, NetworkTests.kt (+3 tests), DispatcherSetupTest.kt (new, 2 tests)

## Tests: 32 before, 37 written now (not run)
No feature removed.
