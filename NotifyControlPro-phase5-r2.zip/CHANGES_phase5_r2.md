# NotifyControlPro phase5-r2: change report

Status: NOT built and NOT run by the author (no Android SDK / Gradle / network in the authoring environment).
No test or build result is claimed. gradle-wrapper.jar is still missing (generate with
`gradle wrapper --gradle-version 8.11.1`). Phase 6 was not started. No feature was removed.

## Fixes
1. DndState now has `access: PolicyAccess { GRANTED, NOT_GRANTED, UNKNOWN }` (+ `canToggle`). A failed read is UNKNOWN, never false.
2. SystemSoundRepository maps the read to the three states. SoundScreen: GRANTED = enabled switch + note;
   NOT_GRANTED = "permission required" + explanation + grant button; UNKNOWN = "could not be read" + button to open the access settings.
   The switch is enabled only for GRANTED.
3. SystemDisplayRepository.setBrightness: Settings.System.canWrite() is now inside the try/catch (SecurityException -> PERMISSION_REQUIRED).
4. Flashlight: torch lookup no longer collapses failures into "no flash". New state FlashlightState.UNKNOWN is emitted when the camera
   service lookup fails or registerTorchCallback throws (CameraAccessException / SecurityException / RuntimeException).
   The lookup is re-evaluated on each collection and request (a transient failure is not cached). Unregistering is guarded. The UI shows
   a clear message for UNKNOWN instead of a switch.
5. Recorder: file handling moved to RecordingStore (no Android dependency, unit-tested). Audio is written to "*.m4a.part" and renamed only
   after a successful stop. Failed start / failed stop / failed rename discard the part file; MediaRecorder is released in every path
   (safeRelease). Stale .part files (crash, killed process) are purged on list(). Delete refuses paths outside the recordings directory.
6. Timer:
   - Notification permission/denial: the note is now shown whenever notifications cannot be shown (permission denied, or notifications
     disabled in system settings), re-evaluated on resume and after the permission dialog. Rule extracted to TimerLogic.notificationsAllowed
     (also used by TimerNotifier).
   - Cancel: cancels the alarm, the posted notification and the saved time; storage errors on cancel no longer crash.
   - Restore: new TimerRepository.restore() re-arms the alarm for a saved, still-future end time. Called from Application.onCreate and
     TimerViewModel init. After a reboot the alarm is lost until the app is opened (no boot receiver): documented in the UI note.
   - start(): if saving fails (IOException) the alarm is cancelled and FAILED is reported.

## Files changed
domain/model: ControlModels.kt, ToolModels.kt | domain/repository: ToolRepositories.kt | domain/tools: TimerAndTime.kt
data/system: SystemSoundRepository, SystemDisplayRepository, SystemFlashlightRepository, SystemRecorderRepository, RecordingStore (new),
DataStoreTimerRepository, TimerNotifier | NotifyControlApp.kt | features/sound/SoundScreen, features/tools/ToolScreens, ToolViewModels
res/values + values-en strings | tests: ControlViewModelTests (constructor update), ToolsTests (fake updated),
RecordingStoreTests (new, 5), Phase5R2Tests (new, 7)

## Tests: 62 before, 74 written now (not run)
Not unit-testable here (Android framework calls): the repositories' SecurityException paths, canWrite handling, torch callback
registration, MediaRecorder release. They are reviewed by reading only.

## Still NOT implemented (unchanged, no buttons exist for them)
Screen recording (MediaProjection foreground service) and Recent Apps (no public API: BLOCKED BY ANDROID).
