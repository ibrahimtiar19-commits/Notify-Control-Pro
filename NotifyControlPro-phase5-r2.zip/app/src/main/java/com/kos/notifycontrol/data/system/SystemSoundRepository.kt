package com.kos.notifycontrol.data.system

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.DndFilter
import com.kos.notifycontrol.domain.model.DndState
import com.kos.notifycontrol.domain.model.PolicyAccess
import com.kos.notifycontrol.domain.model.RingerMode
import com.kos.notifycontrol.domain.model.SoundSnapshot
import com.kos.notifycontrol.domain.model.VolumeState
import com.kos.notifycontrol.domain.model.VolumeStream
import com.kos.notifycontrol.domain.repository.SoundRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

@Singleton
class SystemSoundRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : SoundRepository {
    private val audio = context.getSystemService(AudioManager::class.java)
    private val nm = context.getSystemService(NotificationManager::class.java)

    /** A read the system refuses yields null (the UI then shows "unavailable"), never a default value. */
    private inline fun <T> safe(block: () -> T): T? = try {
        block()
    } catch (e: SecurityException) {
        null
    }

    private fun streamId(s: VolumeStream) = when (s) {
        VolumeStream.MEDIA -> AudioManager.STREAM_MUSIC
        VolumeStream.RING -> AudioManager.STREAM_RING
        VolumeStream.ALARM -> AudioManager.STREAM_ALARM
        VolumeStream.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
        VolumeStream.CALL -> AudioManager.STREAM_VOICE_CALL
    }

    private fun minVolume(s: VolumeStream): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) audio.getStreamMinVolume(streamId(s))
        else if (s == VolumeStream.CALL) 1 else 0

    private fun volumeOf(s: VolumeStream) = VolumeState(
        stream = s,
        current = audio.getStreamVolume(streamId(s)),
        min = minVolume(s),
        max = audio.getStreamMaxVolume(streamId(s))
    )

    override fun read(): SoundSnapshot = SoundSnapshot(
        volumes = if (safe { audio.isVolumeFixed } != false) emptyList()
        else VolumeStream.entries.mapNotNull { s -> safe { volumeOf(s) } },
        ringer = safe { audio.ringerMode }?.let {
            when (it) {
                AudioManager.RINGER_MODE_NORMAL -> RingerMode.NORMAL
                AudioManager.RINGER_MODE_VIBRATE -> RingerMode.VIBRATE
                AudioManager.RINGER_MODE_SILENT -> RingerMode.SILENT
                else -> null
            }
        },
        dnd = DndState(
            access = when (safe { nm.isNotificationPolicyAccessGranted }) {
                true -> PolicyAccess.GRANTED
                false -> PolicyAccess.NOT_GRANTED
                null -> PolicyAccess.UNKNOWN
            },
            filter = when (safe { nm.currentInterruptionFilter }) {
                NotificationManager.INTERRUPTION_FILTER_ALL -> DndFilter.ALL
                NotificationManager.INTERRUPTION_FILTER_PRIORITY -> DndFilter.PRIORITY
                NotificationManager.INTERRUPTION_FILTER_ALARMS -> DndFilter.ALARMS_ONLY
                NotificationManager.INTERRUPTION_FILTER_NONE -> DndFilter.NONE
                else -> DndFilter.UNKNOWN
            }
        )
    )

    override val changes: Flow<Unit> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) { trySend(Unit) }
        }
        val filter = IntentFilter().apply {
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        awaitClose { context.unregisterReceiver(receiver) }
    }

    override fun setVolume(stream: VolumeStream, level: Int): ActionResult = try {
        if (audio.isVolumeFixed) {
            ActionResult.Failure(ActionError.UNSUPPORTED)
        } else {
            val v = volumeOf(stream)
            val target = level.coerceIn(v.min, v.max)
            audio.setStreamVolume(streamId(stream), target, 0)
            val actual = audio.getStreamVolume(streamId(stream))
            if (actual == target) ActionResult.Success(actual) else ActionResult.Failure(ActionError.FAILED)
        }
    } catch (e: SecurityException) {
        // Typically: changing ring/notification volume while a DND policy blocks it.
        ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
    }

    override fun setDnd(on: Boolean): ActionResult = try {
        if (!nm.isNotificationPolicyAccessGranted) {
            ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        } else {
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            ActionResult.Success(if (on) 1 else 0) // request submitted; real state comes from the system
        }
    } catch (e: SecurityException) {
        ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
    }
}
