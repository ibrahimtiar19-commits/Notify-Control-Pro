package com.kos.notifycontrol.features.sound

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.*
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.DndFilter
import com.kos.notifycontrol.domain.model.PolicyAccess
import com.kos.notifycontrol.domain.model.RingerMode
import com.kos.notifycontrol.domain.model.VolumeState
import com.kos.notifycontrol.domain.model.VolumeStream
import kotlin.math.roundToInt

@Composable
fun SoundScreen(modifier: Modifier = Modifier, vm: SoundViewModel = hiltViewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val s = ui.snapshot
    val context = LocalContext.current
    val unavailable = stringResource(R.string.unavailable)
    var launchFailed by remember { mutableStateOf(false) }

    // Per-stream volume has no public change broadcast, so values are re-read on resume.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(stringResource(R.string.sound_title), style = MaterialTheme.typography.headlineMedium)

        SectionCard(stringResource(R.string.volume_title)) {
            if (s.volumes.isEmpty()) {
                Text(stringResource(R.string.action_unsupported))
            } else {
                s.volumes.forEach { v -> VolumeRow(v) { vm.setVolume(v.stream, it) } }
            }
            LabeledRow(stringResource(R.string.ringer_mode), when (s.ringer) {
                RingerMode.NORMAL -> stringResource(R.string.ringer_normal)
                RingerMode.VIBRATE -> stringResource(R.string.ringer_vibrate)
                RingerMode.SILENT -> stringResource(R.string.ringer_silent)
                null -> unavailable
            })
            ErrorText(ui.error)
        }

        SectionCard(stringResource(R.string.dnd_title)) {
            if (s.dnd.filter == DndFilter.UNKNOWN) {
                LabeledRow(stringResource(R.string.state_label), unavailable)
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.dnd_title))
                    Switch(checked = s.dnd.isOn, onCheckedChange = { vm.setDnd(it) }, enabled = s.dnd.canToggle)
                }
            }
            when (s.dnd.access) {
                PolicyAccess.GRANTED ->
                    Text(stringResource(R.string.dnd_on_note), style = MaterialTheme.typography.bodySmall)
                PolicyAccess.NOT_GRANTED -> {
                    Text(stringResource(R.string.permission_required), color = MaterialTheme.colorScheme.error)
                    Text(stringResource(R.string.dnd_explain), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { launchFailed = !context.launchSettings(SettingsIntents.dndAccess()) }) {
                        Text(stringResource(R.string.grant_permission))
                    }
                }
                PolicyAccess.UNKNOWN -> {
                    Text(stringResource(R.string.dnd_access_unknown), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { launchFailed = !context.launchSettings(SettingsIntents.dndAccess()) }) {
                        Text(stringResource(R.string.open_dnd_access_settings))
                    }
                }
            }
        }

        SectionCard(stringResource(R.string.sound_settings_title)) {
            Text(stringResource(R.string.sound_settings_hint), style = MaterialTheme.typography.bodySmall)
            Button(onClick = { launchFailed = !context.launchSettings(SettingsIntents.sound()) }) {
                Text(stringResource(R.string.open_sound_settings))
            }
            if (launchFailed) ErrorText(ActionError.UNSUPPORTED)
        }
    }
}

@Composable
private fun VolumeRow(v: VolumeState, onCommit: (Int) -> Unit) {
    val label = when (v.stream) {
        VolumeStream.MEDIA -> R.string.vol_media
        VolumeStream.RING -> R.string.vol_ring
        VolumeStream.ALARM -> R.string.vol_alarm
        VolumeStream.NOTIFICATION -> R.string.vol_notification
        VolumeStream.CALL -> R.string.vol_call
    }
    var drag by remember(v.current) { mutableStateOf<Float?>(null) }
    LabeledRow(stringResource(label), "${(drag ?: v.current.toFloat()).roundToInt()} / ${v.max}")
    if (v.canAdjust) {
        Slider(
            value = (drag ?: v.current.toFloat()).coerceIn(v.min.toFloat(), v.max.toFloat()),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { onCommit(it.roundToInt()) }; drag = null },
            valueRange = v.min.toFloat()..v.max.toFloat(),
            steps = (v.max - v.min - 1).coerceAtLeast(0)
        )
    }
}
