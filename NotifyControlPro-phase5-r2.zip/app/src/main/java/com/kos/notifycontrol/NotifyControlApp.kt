package com.kos.notifycontrol

import android.app.Application
import com.kos.notifycontrol.domain.repository.TimerRepository
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@HiltAndroidApp
class NotifyControlApp : Application() {
    @Inject lateinit var timer: TimerRepository

    override fun onCreate() {
        super.onCreate()
        // Re-arm the timer notification alarm if a saved timer is still in the future.
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch { timer.restore() }
    }
}
