package com.kos.notifycontrol.data.system

import android.os.BatteryManager
import com.kos.notifycontrol.domain.model.BatteryState
import com.kos.notifycontrol.domain.model.ChargingStatus

/** Pure conversion of raw BatteryManager extras; unit-testable on the JVM. */
object BatteryParser {
    fun parse(level: Int, scale: Int, status: Int, temperatureTenths: Int?): BatteryState {
        val percent = if (level >= 0 && scale > 0) {
            Math.round(level * 100f / scale).coerceIn(0, 100)
        } else null
        val charging = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> ChargingStatus.CHARGING
            BatteryManager.BATTERY_STATUS_DISCHARGING -> ChargingStatus.DISCHARGING
            BatteryManager.BATTERY_STATUS_FULL -> ChargingStatus.FULL
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> ChargingStatus.NOT_CHARGING
            else -> ChargingStatus.UNKNOWN
        }
        return BatteryState(percent, charging, temperatureTenths?.let { it / 10f })
    }
}
