package com.kos.notifycontrol.data.system

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.FlashlightState
import com.kos.notifycontrol.domain.repository.FlashlightRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

@Singleton
class SystemFlashlightRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : FlashlightRepository {
    private val cm = context.getSystemService(CameraManager::class.java)

    private sealed interface Lookup {
        data class Found(val id: String) : Lookup
        data object None : Lookup      // the device has no flash unit
        data object Failed : Lookup    // the camera service refused / failed: NOT the same as "no flash"
    }

    /** Re-evaluated on every collection and request, so a transient camera-service failure is not cached. */
    private fun lookup(): Lookup = try {
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) Lookup.None
        else {
            val withFlash = cm.cameraIdList.filter {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            val id = withFlash.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: withFlash.firstOrNull()
            if (id != null) Lookup.Found(id) else Lookup.None
        }
    } catch (e: CameraAccessException) {
        Lookup.Failed
    } catch (e: SecurityException) {
        Lookup.Failed
    } catch (e: IllegalArgumentException) {
        Lookup.Failed
    }

    override val state: Flow<FlashlightState> = callbackFlow<FlashlightState> {
        var callback: CameraManager.TorchCallback? = null
        when (val l = lookup()) {
            Lookup.None -> trySend(FlashlightState.UNSUPPORTED)
            Lookup.Failed -> trySend(FlashlightState.UNKNOWN)
            is Lookup.Found -> {
                val cb = object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        if (cameraId == l.id) trySend(if (enabled) FlashlightState.ON else FlashlightState.OFF)
                    }
                    override fun onTorchModeUnavailable(cameraId: String) {
                        if (cameraId == l.id) trySend(FlashlightState.UNAVAILABLE)
                    }
                }
                try {
                    cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
                    callback = cb
                } catch (e: CameraAccessException) {
                    trySend(FlashlightState.UNKNOWN)
                } catch (e: SecurityException) {
                    trySend(FlashlightState.UNKNOWN)
                } catch (e: RuntimeException) {
                    trySend(FlashlightState.UNKNOWN)
                }
            }
        }
        awaitClose {
            callback?.let {
                try { cm.unregisterTorchCallback(it) } catch (e: RuntimeException) { /* already gone */ }
            }
        }
    }

    override fun setTorch(on: Boolean): ActionResult {
        val id = when (val l = lookup()) {
            is Lookup.Found -> l.id
            Lookup.None -> return ActionResult.Failure(ActionError.UNSUPPORTED)
            Lookup.Failed -> return ActionResult.Failure(ActionError.FAILED)
        }
        return try {
            cm.setTorchMode(id, on)
            ActionResult.Success(if (on) 1 else 0) // request submitted; the real state comes from the callback
        } catch (e: CameraAccessException) {
            ActionResult.Failure(ActionError.FAILED)
        } catch (e: SecurityException) {
            ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        } catch (e: IllegalArgumentException) {
            ActionResult.Failure(ActionError.FAILED)
        }
    }
}
