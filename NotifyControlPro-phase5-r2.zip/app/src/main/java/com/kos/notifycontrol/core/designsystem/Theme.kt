package com.kos.notifycontrol.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.kos.notifycontrol.domain.model.ThemeMode

val Navy900 = Color(0xFF0B1020)
val Navy800 = Color(0xFF121A2D)
val Blue = Color(0xFF3478F6)
val Cyan = Color(0xFF35C6D8)
val White = Color(0xFFFFFFFF)

private val DarkColors = darkColorScheme(
    primary = Blue, secondary = Cyan, background = Navy900, surface = Navy800,
    surfaceVariant = Navy800, onPrimary = White, onBackground = White, onSurface = White
)
private val LightColors = lightColorScheme(
    primary = Blue, secondary = Cyan, background = Color(0xFFF4F6FB), surface = White,
    surfaceVariant = White, onPrimary = White, onBackground = Navy900, onSurface = Navy900
)

@Composable
fun NotifyControlTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
