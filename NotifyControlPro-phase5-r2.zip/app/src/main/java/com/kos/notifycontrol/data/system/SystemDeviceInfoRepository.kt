package com.kos.notifycontrol.data.system

import android.os.Build
import com.kos.notifycontrol.domain.model.DeviceInfo
import com.kos.notifycontrol.domain.repository.DeviceInfoRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SystemDeviceInfoRepository @Inject constructor() : DeviceInfoRepository {
    override fun read() = DeviceInfo(
        manufacturer = Build.MANUFACTURER?.takeIf { it.isNotBlank() },
        model = Build.MODEL?.takeIf { it.isNotBlank() },
        androidRelease = Build.VERSION.RELEASE?.takeIf { it.isNotBlank() },
        sdkInt = Build.VERSION.SDK_INT
    )
}
