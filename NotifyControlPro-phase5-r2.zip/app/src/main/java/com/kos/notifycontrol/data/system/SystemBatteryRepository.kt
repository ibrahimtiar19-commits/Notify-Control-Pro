package com.kos.notifycontrol.data.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import com.kos.notifycontrol.domain.model.BatteryState
import com.kos.notifycontrol.domain.repository.BatteryRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

@Singleton
class SystemBatteryRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : BatteryRepository {

    private fun Intent.toState(): BatteryState = BatteryParser.parse(
        level = getIntExtra(BatteryManager.EXTRA_LEVEL, -1),
        scale = getIntExtra(BatteryManager.EXTRA_SCALE, -1),
        status = getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN),
        temperatureTenths = if (hasExtra(BatteryManager.EXTRA_TEMPERATURE))
            getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) else null
    )

    override val state: Flow<BatteryState> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                intent?.let { trySend(it.toState()) }
            }
        }
        // ACTION_BATTERY_CHANGED is sticky: registering returns the current value immediately.
        val sticky = ContextCompat.registerReceiver(
            context, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { trySend(it.toState()) }
        awaitClose { context.unregisterReceiver(receiver) }
    }
}
