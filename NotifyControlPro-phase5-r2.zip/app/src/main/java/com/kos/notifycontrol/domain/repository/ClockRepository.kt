package com.kos.notifycontrol.domain.repository

import java.time.ZonedDateTime
import kotlinx.coroutines.flow.Flow

interface ClockRepository {
    /** Emits the real system date-time now, then again on every system minute tick, time or zone change. */
    val now: Flow<ZonedDateTime>
}
