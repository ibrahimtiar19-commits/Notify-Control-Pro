package com.kos.notifycontrol.data.system

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.repository.TimerRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Singleton
class DataStoreTimerRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dataStore: DataStore<Preferences>
) : TimerRepository {
    private val key = longPreferencesKey("timer_end_at")
    private val alarms = context.getSystemService(AlarmManager::class.java)

    private fun pendingIntent() = PendingIntent.getBroadcast(
        context, 1, Intent(context, TimerReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    override val endAtMillis: Flow<Long?> = dataStore.data.map { it[key] }

    private fun schedule(endAt: Long) =
        // Inexact-while-idle alarm: needs no special permission; delivery can be delayed in Doze.
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pendingIntent())

    override suspend fun start(durationMs: Long): ActionResult {
        val endAt = System.currentTimeMillis() + durationMs
        return try {
            schedule(endAt)
            dataStore.edit { it[key] = endAt }
            ActionResult.Success(0)
        } catch (e: SecurityException) {
            ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        } catch (e: IOException) {
            alarms.cancel(pendingIntent()) // nothing was saved: do not leave an alarm without a timer
            ActionResult.Failure(ActionError.FAILED)
        }
    }

    override suspend fun cancel() {
        alarms.cancel(pendingIntent())
        TimerNotifier.cancel(context)
        try {
            dataStore.edit { it.remove(key) }
        } catch (e: IOException) {
            // The alarm is already cancelled; a stale saved time would only show as finished.
        }
    }

    override suspend fun restore() {
        try {
            val endAt = dataStore.data.first()[key] ?: return
            if (endAt > System.currentTimeMillis()) schedule(endAt)
        } catch (e: IOException) {
            // Saved state unreadable: nothing to restore.
        } catch (e: SecurityException) {
            // Alarm could not be re-armed: the in-app countdown still works.
        }
    }
}
