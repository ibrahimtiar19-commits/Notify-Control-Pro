package com.kos.notifycontrol.domain.repository

import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.FlashlightState
import com.kos.notifycontrol.domain.model.Recording
import kotlinx.coroutines.flow.Flow

interface FlashlightRepository {
    /** Real torch state from CameraManager.TorchCallback. */
    val state: Flow<FlashlightState>
    /** Submits the request; the resulting state arrives through [state]. */
    fun setTorch(on: Boolean): ActionResult
}

interface TimerRepository {
    /** Wall-clock end time of the running timer, persisted; null = no timer. */
    val endAtMillis: Flow<Long?>
    suspend fun start(durationMs: Long): ActionResult
    suspend fun cancel()
    /** Re-arms the notification alarm for a saved, still-future end time (alarms do not survive a reboot). */
    suspend fun restore()
}

interface RecorderRepository {
    fun start(): ActionResult
    fun stop(): ActionResult
    fun list(): List<Recording>
    fun delete(name: String): Boolean
}
