package com.kos.notifycontrol.features.network

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.*
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActiveTransport
import com.kos.notifycontrol.domain.model.ToggleState

@Composable
fun NetworkScreen(modifier: Modifier = Modifier, vm: NetworkViewModel = hiltViewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val s = ui.snapshot
    val context = LocalContext.current
    val unavailable = stringResource(R.string.unavailable)
    var launchFailed by remember { mutableStateOf(false) }
    var enableAfterGrant by remember { mutableStateOf(false) }

    // Also covers returning from the app-settings screen after granting the permission there.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    // Bluetooth: the system shows its own "turn on" dialog; the state is then read from the system.
    val enableLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.refresh() }
    fun launchEnable() {
        runCatching { enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
            .onFailure { launchFailed = true }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.onBluetoothPermissionResult(granted) // re-reads the real state either way
        if (granted && enableAfterGrant && vm.state.value.snapshot.bluetooth == ToggleState.OFF) launchEnable()
        enableAfterGrant = false
    }
    fun hasBluetoothPermission() = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    fun requestBluetoothPermission(thenEnable: Boolean) {
        vm.clearError()
        enableAfterGrant = thenEnable
        permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
    }
    fun requestBluetoothOn() {
        vm.clearError()
        if (hasBluetoothPermission()) launchEnable() else requestBluetoothPermission(thenEnable = true)
    }
    fun open(intent: Intent) { launchFailed = !context.launchSettings(intent) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(stringResource(R.string.network_title), style = MaterialTheme.typography.headlineMedium)

        SectionCard(stringResource(R.string.wifi_title)) {
            LabeledRow(stringResource(R.string.state_label), s.wifi?.let { toggleLabel(it) } ?: unavailable)
            if (s.wifi != null) {
                Text(stringResource(R.string.wifi_note), style = MaterialTheme.typography.bodySmall)
                Button(onClick = { open(SettingsIntents.wifi()) }) { Text(stringResource(R.string.open_wifi_panel)) }
            }
        }

        SectionCard(stringResource(R.string.bluetooth_title)) {
            val bt = s.bluetooth
            LabeledRow(stringResource(R.string.state_label), bt?.let { toggleLabel(it) } ?: unavailable)
            when (bt) {
                null -> Unit
                ToggleState.PERMISSION_REQUIRED -> {
                    Text(stringResource(R.string.bluetooth_permission_explain), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { requestBluetoothPermission(thenEnable = false) }) {
                        Text(stringResource(R.string.grant_permission))
                    }
                }
                else -> {
                    if (bt == ToggleState.OFF) {
                        Button(onClick = { requestBluetoothOn() }) { Text(stringResource(R.string.bluetooth_turn_on)) }
                    }
                    Text(stringResource(R.string.bluetooth_note), style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = { open(SettingsIntents.bluetooth()) }) {
                        Text(stringResource(R.string.open_bluetooth_settings))
                    }
                }
            }
            ErrorText(ui.error)
            if (ui.error == ActionError.PERMISSION_REQUIRED) {
                // If the system no longer shows the dialog, the permission can only be granted here.
                OutlinedButton(onClick = { open(SettingsIntents.appDetails(context.packageName)) }) {
                    Text(stringResource(R.string.open_app_settings))
                }
            }
        }

        SectionCard(stringResource(R.string.mobile_data_title)) {
            LabeledRow(stringResource(R.string.active_connection), when (s.transport) {
                ActiveTransport.WIFI -> stringResource(R.string.transport_wifi)
                ActiveTransport.CELLULAR -> stringResource(R.string.transport_cellular)
                ActiveTransport.ETHERNET -> stringResource(R.string.transport_ethernet)
                ActiveTransport.OTHER -> stringResource(R.string.transport_other)
                ActiveTransport.NONE -> stringResource(R.string.transport_none)
                ActiveTransport.UNKNOWN -> unavailable
            })
            if (s.transport != ActiveTransport.NONE && s.transport != ActiveTransport.UNKNOWN) {
                LabeledRow(stringResource(R.string.internet_validated),
                    stringResource(if (s.internetValidated) R.string.yes else R.string.no))
            }
            Text(stringResource(R.string.mobile_data_note), style = MaterialTheme.typography.bodySmall)
            Button(onClick = { open(SettingsIntents.internet()) }) { Text(stringResource(R.string.open_internet_settings)) }
        }

        SectionCard(stringResource(R.string.airplane_title)) {
            LabeledRow(stringResource(R.string.state_label), s.airplaneMode?.let {
                stringResource(if (it) R.string.on else R.string.off)
            } ?: unavailable)
            Text(stringResource(R.string.airplane_note), style = MaterialTheme.typography.bodySmall)
            Button(onClick = { open(SettingsIntents.airplane()) }) { Text(stringResource(R.string.open_airplane_settings)) }
        }

        SectionCard(stringResource(R.string.hotspot_title)) {
            LabeledRow(stringResource(R.string.state_label), unavailable)
            Text(stringResource(R.string.hotspot_note), style = MaterialTheme.typography.bodySmall)
            Button(onClick = { open(SettingsIntents.wireless()) }) { Text(stringResource(R.string.open_network_settings)) }
        }

        if (launchFailed) ErrorText(ActionError.UNSUPPORTED)
    }
}

@Composable
private fun toggleLabel(t: ToggleState): String = when (t) {
    ToggleState.ON -> stringResource(R.string.on)
    ToggleState.OFF -> stringResource(R.string.off)
    ToggleState.TURNING_ON -> stringResource(R.string.turning_on)
    ToggleState.TURNING_OFF -> stringResource(R.string.turning_off)
    ToggleState.UNKNOWN -> stringResource(R.string.unavailable)
    ToggleState.PERMISSION_REQUIRED -> stringResource(R.string.permission_required)
}
