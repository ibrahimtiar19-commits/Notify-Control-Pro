package com.kos.notifycontrol.features.dashboard

import android.text.format.Formatter
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.Alignment
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.domain.model.ChargingStatus
import com.kos.notifycontrol.domain.model.Reading
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
fun DashboardScreen(
    modifier: Modifier = Modifier,
    onOpenSettings: () -> Unit = {},
    vm: DashboardViewModel = hiltViewModel()
) {
    val now by vm.now.collectAsStateWithLifecycle()
    val battery by vm.battery.collectAsStateWithLifecycle()
    val storage by vm.storage.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val unavailable = stringResource(R.string.unavailable)

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshStorage() }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.dashboard_title), style = MaterialTheme.typography.headlineMedium)
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.nav_settings))
            }
        }

        InfoCard(stringResource(R.string.clock_card_title)) {
            now?.let { t ->
                Text(t.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)),
                    style = MaterialTheme.typography.displayMedium)
                Text(t.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)),
                    style = MaterialTheme.typography.bodyLarge)
            }
        }

        InfoCard(stringResource(R.string.battery_title)) {
            battery?.let { b ->
                InfoRow(stringResource(R.string.battery_level),
                    b.levelPercent?.let { stringResource(R.string.percent_fmt, it) } ?: unavailable)
                b.levelPercent?.let {
                    LinearProgressIndicator(progress = { it / 100f }, modifier = Modifier.fillMaxWidth())
                }
                InfoRow(stringResource(R.string.charging_status), chargingLabel(b.charging) ?: unavailable)
                InfoRow(stringResource(R.string.battery_temperature),
                    b.temperatureCelsius?.let { stringResource(R.string.celsius_fmt, it) } ?: unavailable)
            }
        }

        InfoCard(stringResource(R.string.storage_title)) {
            when (val s = storage) {
                Reading.Loading -> Unit
                Reading.Unavailable -> Text(unavailable)
                is Reading.Available -> {
                    val v = s.value
                    LinearProgressIndicator(progress = { v.usedFraction }, modifier = Modifier.fillMaxWidth())
                    InfoRow(stringResource(R.string.storage_used), Formatter.formatFileSize(context, v.usedBytes))
                    InfoRow(stringResource(R.string.storage_free), Formatter.formatFileSize(context, v.availableBytes))
                    InfoRow(stringResource(R.string.storage_total), Formatter.formatFileSize(context, v.totalBytes))
                }
            }
        }

        InfoCard(stringResource(R.string.device_title)) {
            val d = vm.deviceInfo
            InfoRow(stringResource(R.string.device_manufacturer), d.manufacturer ?: unavailable)
            InfoRow(stringResource(R.string.device_model), d.model ?: unavailable)
            InfoRow(stringResource(R.string.device_android), d.androidRelease ?: unavailable)
            InfoRow(stringResource(R.string.device_sdk), d.sdkInt.toString())
        }
    }
}

@Composable
private fun chargingLabel(s: ChargingStatus): String? = when (s) {
    ChargingStatus.CHARGING -> stringResource(R.string.status_charging)
    ChargingStatus.DISCHARGING -> stringResource(R.string.status_discharging)
    ChargingStatus.FULL -> stringResource(R.string.status_full)
    ChargingStatus.NOT_CHARGING -> stringResource(R.string.status_not_charging)
    ChargingStatus.UNKNOWN -> null
}

@Composable
private fun InfoCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            content()
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
