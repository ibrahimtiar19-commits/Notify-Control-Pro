package com.kos.notifycontrol.domain.model

enum class ActionError { PERMISSION_REQUIRED, UNSUPPORTED, FAILED }

/** Success carries the value read back from the system after the change, never an assumed value. */
sealed interface ActionResult {
    data class Success(val verifiedValue: Int) : ActionResult
    data class Failure(val error: ActionError) : ActionResult
}

enum class VolumeStream { MEDIA, RING, ALARM, NOTIFICATION, CALL }

data class VolumeState(val stream: VolumeStream, val current: Int, val min: Int, val max: Int) {
    val canAdjust: Boolean get() = max > min
    val fraction: Float get() = if (max > min) ((current - min).toFloat() / (max - min)).coerceIn(0f, 1f) else 0f
}

enum class RingerMode { NORMAL, VIBRATE, SILENT }

enum class DndFilter { ALL, PRIORITY, ALARMS_ONLY, NONE, UNKNOWN }

/** UNKNOWN = the system refused to say (SecurityException); it is never folded into NOT_GRANTED. */
enum class PolicyAccess { GRANTED, NOT_GRANTED, UNKNOWN }

data class DndState(val access: PolicyAccess, val filter: DndFilter) {
    val isOn: Boolean get() = filter == DndFilter.PRIORITY || filter == DndFilter.ALARMS_ONLY || filter == DndFilter.NONE
    val canToggle: Boolean get() = access == PolicyAccess.GRANTED
}

data class SoundSnapshot(
    /** Empty when the device has fixed volume (no adjustable streams). */
    val volumes: List<VolumeState>,
    val ringer: RingerMode?,
    val dnd: DndState
)

/** null fields = the system did not provide the value. */
data class DisplaySnapshot(
    val brightness: Int?,          // raw system value 0..255
    val autoBrightness: Boolean?,
    val canWriteSettings: Boolean,
    val screenTimeoutMs: Int?,
    val autoRotate: Boolean?,
    val fontScale: Float,
    val darkTheme: Boolean
)
