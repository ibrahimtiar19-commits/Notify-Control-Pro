package com.kos.notifycontrol.domain.model

enum class ChargingStatus { CHARGING, DISCHARGING, FULL, NOT_CHARGING, UNKNOWN }

/** levelPercent / temperatureCelsius are null when the system did not report them. */
data class BatteryState(
    val levelPercent: Int?,
    val charging: ChargingStatus,
    val temperatureCelsius: Float?
)

data class StorageState(val totalBytes: Long, val availableBytes: Long) {
    val usedBytes: Long get() = totalBytes - availableBytes
    val usedFraction: Float get() = if (totalBytes > 0) usedBytes.toFloat() / totalBytes else 0f
}

/** Fields are null when the system returns an empty value. */
data class DeviceInfo(
    val manufacturer: String?,
    val model: String?,
    val androidRelease: String?,
    val sdkInt: Int
)
