package com.kos.notifycontrol.domain.model

/**
 * UNSUPPORTED = no flash unit; UNAVAILABLE = the system reports the torch as in use elsewhere;
 * UNKNOWN = the system refused or failed to report the torch state (never shown as OFF).
 */
enum class FlashlightState { UNSUPPORTED, UNAVAILABLE, UNKNOWN, OFF, ON }

data class Recording(val name: String, val path: String, val sizeBytes: Long, val modifiedMillis: Long)
