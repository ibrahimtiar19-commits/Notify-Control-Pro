package com.kos.notifycontrol.features.display

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.*
import kotlin.math.roundToInt

@Composable
fun DisplayScreen(modifier: Modifier = Modifier, vm: DisplayViewModel = hiltViewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val s = ui.snapshot
    val context = LocalContext.current
    val unavailable = stringResource(R.string.unavailable)
    var launchFailed by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(stringResource(R.string.display_title), style = MaterialTheme.typography.headlineMedium)

        SectionCard(stringResource(R.string.brightness_title)) {
            val raw = s.brightness
            if (raw == null) {
                Text(unavailable)
            } else {
                var drag by remember(raw) { mutableStateOf<Float?>(null) }
                val shown = drag ?: raw.toFloat()
                LabeledRow(stringResource(R.string.brightness_system),
                    stringResource(R.string.percent_fmt, (shown * 100 / 255f).roundToInt()))
                Slider(
                    value = shown.coerceIn(1f, 255f),
                    onValueChange = { drag = it },
                    onValueChangeFinished = { drag?.let { vm.setBrightness(it.roundToInt()) }; drag = null },
                    valueRange = 1f..255f,
                    enabled = s.canWriteSettings
                )
                s.autoBrightness?.let {
                    LabeledRow(stringResource(R.string.brightness_auto),
                        stringResource(if (it) R.string.on else R.string.off))
                }
                if (!s.canWriteSettings) {
                    Text(stringResource(R.string.permission_required), color = MaterialTheme.colorScheme.error)
                    Text(stringResource(R.string.write_settings_explain), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        launchFailed = !context.launchSettings(SettingsIntents.writeSettings(context.packageName))
                    }) { Text(stringResource(R.string.grant_permission)) }
                }
            }
            ErrorText(ui.error)
        }

        SectionCard(stringResource(R.string.display_info_title)) {
            LabeledRow(stringResource(R.string.screen_timeout),
                s.screenTimeoutMs?.let { stringResource(R.string.seconds_fmt, it / 1000) } ?: unavailable)
            LabeledRow(stringResource(R.string.auto_rotate),
                s.autoRotate?.let { stringResource(if (it) R.string.on else R.string.off) } ?: unavailable)
            LabeledRow(stringResource(R.string.font_scale), stringResource(R.string.scale_fmt, s.fontScale))
            LabeledRow(stringResource(R.string.dark_theme),
                stringResource(if (s.darkTheme) R.string.on else R.string.off))
            Text(stringResource(R.string.display_settings_hint), style = MaterialTheme.typography.bodySmall)
            Button(onClick = { launchFailed = !context.launchSettings(SettingsIntents.display()) }) {
                Text(stringResource(R.string.open_display_settings))
            }
            if (launchFailed) ErrorText(com.kos.notifycontrol.domain.model.ActionError.UNSUPPORTED)
        }
    }
}
