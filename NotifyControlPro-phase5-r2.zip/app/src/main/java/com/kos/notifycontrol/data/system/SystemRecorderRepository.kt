package com.kos.notifycontrol.data.system

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import androidx.core.content.ContextCompat
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.Recording
import com.kos.notifycontrol.domain.repository.RecorderRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/** Records to the app's private storage (no storage permission). Only the microphone permission is needed. */
@Singleton
class SystemRecorderRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : RecorderRepository {
    private val store = RecordingStore(File(context.filesDir, "recordings"))
    private var recorder: MediaRecorder? = null
    private var currentPart: File? = null

    private fun safeRelease(r: MediaRecorder) {
        try { r.release() } catch (e: Exception) { /* nothing left to free */ }
    }

    override fun start(): ActionResult {
        if (recorder != null) return ActionResult.Failure(ActionError.FAILED)
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE))
            return ActionResult.Failure(ActionError.UNSUPPORTED)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            return ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        val part = store.newPartFile(SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()))
        var r: MediaRecorder? = null
        return try {
            @Suppress("DEPRECATION")
            r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(part.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            currentPart = part
            ActionResult.Success(1)
        } catch (e: SecurityException) {
            r?.let(::safeRelease); store.discard(part)
            ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        } catch (e: Exception) {
            r?.let(::safeRelease); store.discard(part)
            ActionResult.Failure(ActionError.FAILED)
        }
    }

    override fun stop(): ActionResult {
        val r = recorder ?: return ActionResult.Failure(ActionError.FAILED)
        val part = currentPart
        recorder = null
        currentPart = null
        val stopped = try {
            r.stop()
            true
        } catch (e: RuntimeException) {
            false // stop() throws when no valid audio was captured
        } finally {
            safeRelease(r)
        }
        if (part == null) return ActionResult.Failure(ActionError.FAILED)
        if (!stopped) {
            store.discard(part)
            return ActionResult.Failure(ActionError.FAILED)
        }
        if (store.commit(part) == null) {
            store.discard(part)
            return ActionResult.Failure(ActionError.FAILED)
        }
        return ActionResult.Success(0)
    }

    override fun list(): List<Recording> = store.list(currentPart)

    override fun delete(name: String): Boolean = store.delete(name)
}
