package com.kos.notifycontrol.data.system

import android.content.Context
import android.content.res.Configuration
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.DisplaySnapshot
import com.kos.notifycontrol.domain.repository.DisplayRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

@Singleton
class SystemDisplayRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : DisplayRepository {
    private val resolver = context.contentResolver

    private fun systemInt(name: String): Int? = try {
        Settings.System.getInt(resolver, name)
    } catch (e: Settings.SettingNotFoundException) {
        null
    } catch (e: SecurityException) {
        null
    }

    override fun read(): DisplaySnapshot {
        val cfg = context.resources.configuration
        return DisplaySnapshot(
            brightness = systemInt(Settings.System.SCREEN_BRIGHTNESS),
            autoBrightness = systemInt(Settings.System.SCREEN_BRIGHTNESS_MODE)
                ?.let { it == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC },
            canWriteSettings = try { Settings.System.canWrite(context) } catch (e: SecurityException) { false },
            screenTimeoutMs = systemInt(Settings.System.SCREEN_OFF_TIMEOUT),
            autoRotate = systemInt(Settings.System.ACCELEROMETER_ROTATION)?.let { it == 1 },
            fontScale = cfg.fontScale,
            darkTheme = (cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        )
    }

    override val changes: Flow<Unit> = callbackFlow {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) { trySend(Unit) }
        }
        listOf(
            Settings.System.SCREEN_BRIGHTNESS, Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_OFF_TIMEOUT, Settings.System.ACCELEROMETER_ROTATION
        ).forEach { resolver.registerContentObserver(Settings.System.getUriFor(it), false, observer) }
        awaitClose { resolver.unregisterContentObserver(observer) }
    }

    override fun setBrightness(raw: Int): ActionResult {
        val target = raw.coerceIn(0, 255)
        return try {
            if (!Settings.System.canWrite(context)) {
                ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
            } else {
                val ok = Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, target)
                val actual = systemInt(Settings.System.SCREEN_BRIGHTNESS)
                if (ok && actual == target) ActionResult.Success(target) else ActionResult.Failure(ActionError.FAILED)
            }
        } catch (e: SecurityException) {
            ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        }
    }
}
