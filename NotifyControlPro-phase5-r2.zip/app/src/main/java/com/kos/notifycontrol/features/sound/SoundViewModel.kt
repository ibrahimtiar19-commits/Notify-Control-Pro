package com.kos.notifycontrol.features.sound

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.SoundSnapshot
import com.kos.notifycontrol.domain.model.VolumeStream
import com.kos.notifycontrol.domain.repository.SoundRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SoundUiState(val snapshot: SoundSnapshot, val error: ActionError? = null)

@HiltViewModel
class SoundViewModel @Inject constructor(private val repo: SoundRepository) : ViewModel() {
    private val _state = MutableStateFlow(SoundUiState(repo.read()))
    val state: StateFlow<SoundUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { repo.changes.collect { refresh() } }
    }

    fun refresh() { _state.value = _state.value.copy(snapshot = repo.read()) }

    fun clearError() { _state.value = _state.value.copy(error = null) }

    fun setVolume(stream: VolumeStream, level: Int) {
        val error = (repo.setVolume(stream, level) as? ActionResult.Failure)?.error
        _state.value = SoundUiState(repo.read(), error) // always re-read: the UI shows the real value
    }

    fun setDnd(on: Boolean) {
        val error = (repo.setDnd(on) as? ActionResult.Failure)?.error
        _state.value = SoundUiState(repo.read(), error)
    }
}
