package com.kos.notifycontrol.features.tools

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.*
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.FlashlightState
import com.kos.notifycontrol.domain.tools.CalcError
import com.kos.notifycontrol.domain.tools.TimerLogic
import com.kos.notifycontrol.domain.tools.TimerStatus
import com.kos.notifycontrol.domain.tools.formatClock
import java.io.File
import kotlinx.coroutines.delay

object ToolRoutes {
    const val FLASHLIGHT = "tools/flashlight"
    const val CALCULATOR = "tools/calculator"
    const val TIMER = "tools/timer"
    const val STOPWATCH = "tools/stopwatch"
    const val RECORDER = "tools/recorder"
}

@Composable
private fun ToolPage(title: String, modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        content()
    }
}

// ---------------- Hub ----------------
@Composable
fun ToolsScreen(modifier: Modifier = Modifier, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    var launchFailed by remember { mutableStateOf(false) }
    fun launch(intent: Intent) { launchFailed = !context.launchSettings(intent) }
    ToolPage(stringResource(R.string.tools_title), modifier) {
        SectionCard(stringResource(R.string.tools_title)) {
            listOf(
                R.string.tool_flashlight to ToolRoutes.FLASHLIGHT,
                R.string.tool_calculator to ToolRoutes.CALCULATOR,
                R.string.tool_timer to ToolRoutes.TIMER,
                R.string.tool_stopwatch to ToolRoutes.STOPWATCH,
                R.string.tool_recorder to ToolRoutes.RECORDER
            ).forEach { (label, route) ->
                Button(onClick = { onOpen(route) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(label)) }
            }
        }
        SectionCard(stringResource(R.string.shortcuts_title)) {
            OutlinedButton(onClick = { launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.open_camera))
            }
            OutlinedButton(onClick = { launch(SettingsIntents.appDetails(context.packageName)) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.open_app_settings))
            }
            OutlinedButton(onClick = { launch(Intent(Settings.ACTION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.open_system_settings))
            }
            if (launchFailed) ErrorText(ActionError.UNSUPPORTED)
        }
    }
}

// ---------------- Flashlight ----------------
@Composable
fun FlashlightScreen(modifier: Modifier = Modifier, vm: FlashlightViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    ToolPage(stringResource(R.string.tool_flashlight), modifier) {
        SectionCard(stringResource(R.string.tool_flashlight)) {
            when (state) {
                null -> Unit
                FlashlightState.UNSUPPORTED -> Text(stringResource(R.string.flashlight_unsupported))
                FlashlightState.UNAVAILABLE -> Text(stringResource(R.string.flashlight_unavailable))
                FlashlightState.UNKNOWN -> Text(stringResource(R.string.flashlight_unknown))
                FlashlightState.OFF, FlashlightState.ON -> Row(
                    Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(if (state == FlashlightState.ON) R.string.on else R.string.off))
                    Switch(checked = state == FlashlightState.ON, onCheckedChange = { vm.setTorch(it) })
                }
            }
            ErrorText(error)
        }
    }
}

// ---------------- Calculator ----------------
@Composable
fun CalculatorScreen(modifier: Modifier = Modifier, vm: CalculatorViewModel = hiltViewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val backspaceDescription = stringResource(R.string.calc_backspace)
    val rows = listOf("C⌫%÷", "789×", "456-", "123+", "()0.")
    // Numbers and keypad stay left-to-right even in Arabic.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        ToolPage(stringResource(R.string.tool_calculator), modifier) {
            SectionCard(stringResource(R.string.tool_calculator)) {
                Text(ui.expression.ifEmpty { "0" }, style = MaterialTheme.typography.headlineMedium)
                Text(
                    ui.result ?: when (ui.error) {
                        CalcError.DIVISION_BY_ZERO -> stringResource(R.string.calc_error_div_zero)
                        CalcError.SYNTAX -> stringResource(R.string.calc_error_syntax)
                        null -> ""
                    },
                    style = MaterialTheme.typography.titleLarge,
                    color = if (ui.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                )
            }
            rows.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { key ->
                        Button(
                            onClick = {
                                when (key) {
                                    'C' -> vm.clear()
                                    '⌫' -> vm.backspace()
                                    else -> vm.onKey(key)
                                }
                            },
                            modifier = Modifier.weight(1f).heightIn(min = 56.dp).then(
                                if (key == '⌫') Modifier.semantics { contentDescription = backspaceDescription } else Modifier
                            )
                        ) { Text(key.toString(), style = MaterialTheme.typography.titleLarge) }
                    }
                }
            }
            Button(onClick = { vm.equals() }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("=", style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

// ---------------- Timer ----------------
@Composable
fun TimerScreen(modifier: Modifier = Modifier, vm: TimerViewModel = hiltViewModel()) {
    val endAt by vm.endAt.collectAsStateWithLifecycle()
    val invalid by vm.invalidInput.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var minutes by remember { mutableStateOf("") }
    var seconds by remember { mutableStateOf("") }
    var permissionTick by remember { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<Pair<String, String>?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Ticks only while a timer is running and this screen is visible.
    LaunchedEffect(endAt) {
        val end = endAt
        while (end != null && System.currentTimeMillis() < end) { now = System.currentTimeMillis(); delay(250) }
        now = System.currentTimeMillis()
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        permissionTick++ // re-evaluate whether notifications can actually be shown
        pending?.let { vm.start(it.first, it.second) }
        pending = null
    }
    fun start() {
        val needs = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needs) { pending = minutes to seconds; permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
        else vm.start(minutes, seconds)
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { permissionTick++ } // e.g. returning from system settings
    val notificationsAllowed = remember(permissionTick) {
        TimerLogic.notificationsAllowed(
            Build.VERSION.SDK_INT,
            NotificationManagerCompat.from(context).areNotificationsEnabled(),
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        )
    }
    val status = TimerLogic.status(endAt, now)
    ToolPage(stringResource(R.string.tool_timer), modifier) {
        SectionCard(stringResource(R.string.tool_timer)) {
            when (status) {
                TimerStatus.IDLE -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit).take(4) },
                            label = { Text(stringResource(R.string.timer_minutes)) }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                        OutlinedTextField(seconds, { seconds = it.filter(Char::isDigit).take(2) },
                            label = { Text(stringResource(R.string.timer_seconds)) }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    }
                    if (invalid) Text(stringResource(R.string.timer_invalid), color = MaterialTheme.colorScheme.error)
                    Button(onClick = { start() }) { Text(stringResource(R.string.start)) }
                }
                TimerStatus.RUNNING -> {
                    Text(formatClock(TimerLogic.remainingMillis(endAt!!, now), withCentis = false),
                        style = MaterialTheme.typography.displayMedium)
                    OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
                }
                TimerStatus.FINISHED -> {
                    Text(stringResource(R.string.timer_finished_title), style = MaterialTheme.typography.headlineMedium)
                    Button(onClick = { vm.cancel() }) { Text(stringResource(R.string.timer_dismiss)) }
                }
            }
            if (!notificationsAllowed) Text(stringResource(R.string.timer_notification_denied), style = MaterialTheme.typography.bodySmall)
            ErrorText(error)
            Text(stringResource(R.string.timer_doze_note), style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ---------------- Stopwatch ----------------
@Composable
fun StopwatchScreen(modifier: Modifier = Modifier, vm: StopwatchViewModel = hiltViewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    var elapsed by remember { mutableLongStateOf(vm.elapsedMillis()) }
    LaunchedEffect(ui.running) {
        while (true) { elapsed = vm.elapsedMillis(); if (!ui.running) break; delay(50) }
    }
    ToolPage(stringResource(R.string.tool_stopwatch), modifier) {
        SectionCard(stringResource(R.string.tool_stopwatch)) {
            Text(formatClock(elapsed, withCentis = true), style = MaterialTheme.typography.displayMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (ui.running) Button(onClick = { vm.pause() }) { Text(stringResource(R.string.pause)) }
                else Button(onClick = { vm.start() }) { Text(stringResource(R.string.start)) }
                OutlinedButton(onClick = { vm.lap() }, enabled = ui.running) { Text(stringResource(R.string.lap)) }
                OutlinedButton(onClick = { vm.reset() }, enabled = ui.running || elapsed > 0) { Text(stringResource(R.string.reset)) }
            }
            ui.laps.forEachIndexed { i, ms -> LabeledRow(stringResource(R.string.lap_n, i + 1), formatClock(ms, withCentis = true)) }
        }
    }
}

// ---------------- Voice recorder ----------------
@Composable
fun RecorderScreen(modifier: Modifier = Modifier, vm: RecorderViewModel = hiltViewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var elapsed by remember { mutableLongStateOf(0L) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.stopIfRecording() }
    LaunchedEffect(ui.recording) {
        while (ui.recording) { elapsed = vm.elapsedMillis(); delay(250) }
        elapsed = 0
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.start() else vm.onMicPermissionDenied()
    }
    fun startRecording() {
        vm.clearError()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.start()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    ToolPage(stringResource(R.string.tool_recorder), modifier) {
        SectionCard(stringResource(R.string.tool_recorder)) {
            if (ui.recording) {
                Text(formatClock(elapsed, withCentis = false), style = MaterialTheme.typography.displayMedium)
                Button(onClick = { vm.stop() }) { Text(stringResource(R.string.recorder_stop)) }
            } else {
                Button(onClick = { startRecording() }) { Text(stringResource(R.string.recorder_start)) }
            }
            Text(stringResource(R.string.recorder_note), style = MaterialTheme.typography.bodySmall)
            ErrorText(ui.error)
        }
        SectionCard(stringResource(R.string.recordings_title)) {
            if (ui.recordings.isEmpty()) Text(stringResource(R.string.no_recordings))
            ui.recordings.forEach { rec ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    LabeledRow(rec.name, android.text.format.Formatter.formatFileSize(context, rec.sizeBytes))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", File(rec.path))
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "audio/mp4"; putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.launchSettings(Intent.createChooser(send, null))
                        }) { Text(stringResource(R.string.share)) }
                        OutlinedButton(onClick = { vm.delete(rec.name) }) { Text(stringResource(R.string.delete)) }
                    }
                }
            }
        }
    }
}
