package com.kos.notifycontrol.navigation

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kos.notifycontrol.R
import com.kos.notifycontrol.features.dashboard.DashboardScreen
import com.kos.notifycontrol.features.display.DisplayScreen
import com.kos.notifycontrol.features.network.NetworkScreen
import com.kos.notifycontrol.features.settings.SettingsScreen
import com.kos.notifycontrol.features.sound.SoundScreen
import com.kos.notifycontrol.features.tools.CalculatorScreen
import com.kos.notifycontrol.features.tools.FlashlightScreen
import com.kos.notifycontrol.features.tools.RecorderScreen
import com.kos.notifycontrol.features.tools.StopwatchScreen
import com.kos.notifycontrol.features.tools.TimerScreen
import com.kos.notifycontrol.features.tools.ToolRoutes
import com.kos.notifycontrol.features.tools.ToolsScreen

/** Bottom-bar destinations (Settings is opened from the Dashboard header). */
enum class Destination(val route: String, @StringRes val label: Int, val icon: ImageVector) {
    Dashboard("dashboard", R.string.nav_dashboard, Icons.Filled.Home),
    Display("display", R.string.nav_display, Icons.Filled.Phone),
    Sound("sound", R.string.nav_sound, Icons.Filled.Notifications),
    Network("network", R.string.nav_network, Icons.Filled.Share),
    Tools("tools", R.string.nav_tools, Icons.Filled.Build)
}

const val SETTINGS_ROUTE = "settings"

@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(bottomBar = {
        NavigationBar {
            Destination.entries.forEach { d ->
                NavigationBarItem(
                    selected = current == d.route || (d == Destination.Tools && current?.startsWith("tools/") == true),
                    onClick = {
                        nav.navigate(d.route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true; restoreState = true
                        }
                    },
                    icon = { Icon(d.icon, contentDescription = null) },
                    label = { Text(stringResource(d.label)) }
                )
            }
        }
    }) { pad ->
        val m = Modifier.padding(pad)
        NavHost(nav, startDestination = Destination.Dashboard.route) {
            composable(Destination.Dashboard.route) { DashboardScreen(m, onOpenSettings = { nav.navigate(SETTINGS_ROUTE) }) }
            composable(Destination.Display.route) { DisplayScreen(m) }
            composable(Destination.Sound.route) { SoundScreen(m) }
            composable(Destination.Network.route) { NetworkScreen(m) }
            composable(Destination.Tools.route) { ToolsScreen(m, onOpen = { nav.navigate(it) }) }
            composable(ToolRoutes.FLASHLIGHT) { FlashlightScreen(m) }
            composable(ToolRoutes.CALCULATOR) { CalculatorScreen(m) }
            composable(ToolRoutes.TIMER) { TimerScreen(m) }
            composable(ToolRoutes.STOPWATCH) { StopwatchScreen(m) }
            composable(ToolRoutes.RECORDER) { RecorderScreen(m) }
            composable(SETTINGS_ROUTE) { SettingsScreen(m) }
        }
    }
}
