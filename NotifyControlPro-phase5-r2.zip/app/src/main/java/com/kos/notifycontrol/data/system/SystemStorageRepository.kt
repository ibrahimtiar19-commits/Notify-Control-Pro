package com.kos.notifycontrol.data.system

import android.os.Environment
import android.os.StatFs
import com.kos.notifycontrol.domain.model.StorageState
import com.kos.notifycontrol.domain.repository.StorageRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Singleton
class SystemStorageRepository @Inject constructor() : StorageRepository {
    override suspend fun read(): StorageState? = withContext(Dispatchers.IO) {
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            StorageState(totalBytes = stat.totalBytes, availableBytes = stat.availableBytes)
                .takeIf { it.totalBytes > 0 }
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}
