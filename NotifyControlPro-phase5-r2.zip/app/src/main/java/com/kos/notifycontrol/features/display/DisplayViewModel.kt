package com.kos.notifycontrol.features.display

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.DisplaySnapshot
import com.kos.notifycontrol.domain.repository.DisplayRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DisplayUiState(val snapshot: DisplaySnapshot, val error: ActionError? = null)

@HiltViewModel
class DisplayViewModel @Inject constructor(private val repo: DisplayRepository) : ViewModel() {
    private val _state = MutableStateFlow(DisplayUiState(repo.read()))
    val state: StateFlow<DisplayUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { repo.changes.collect { refresh() } }
    }

    fun refresh() { _state.value = _state.value.copy(snapshot = repo.read()) }

    fun clearError() { _state.value = _state.value.copy(error = null) }

    /** Never calls the system without the WRITE_SETTINGS grant; the shown value always comes from a re-read. */
    fun setBrightness(raw: Int) {
        if (!_state.value.snapshot.canWriteSettings) {
            _state.value = _state.value.copy(error = ActionError.PERMISSION_REQUIRED)
            return
        }
        val error = (repo.setBrightness(raw) as? ActionResult.Failure)?.error
        _state.value = DisplayUiState(repo.read(), error)
    }
}
