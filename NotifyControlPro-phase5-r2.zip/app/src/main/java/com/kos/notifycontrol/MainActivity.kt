package com.kos.notifycontrol

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.core.designsystem.NotifyControlTheme
import com.kos.notifycontrol.features.settings.SettingsViewModel
import com.kos.notifycontrol.navigation.AppNavigation
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: SettingsViewModel = hiltViewModel()
            val mode by vm.themeMode.collectAsStateWithLifecycle()
            NotifyControlTheme(mode) { AppNavigation() }
        }
    }
}
