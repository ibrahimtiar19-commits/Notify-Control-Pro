package com.kos.notifycontrol.data.system

import com.kos.notifycontrol.domain.model.Recording
import java.io.File

/**
 * File handling for recordings, with no Android dependency (unit-testable).
 * While recording, audio goes to "<name>.m4a.part"; it only becomes "<name>.m4a" after a successful stop,
 * so a failed or interrupted recording never shows up as a real recording and stale parts are purged.
 */
class RecordingStore(private val dir: File) {
    init { dir.mkdirs() }

    fun newPartFile(timestamp: String) = File(dir, "rec_$timestamp.m4a.part")

    /** Renames the part file to its final name. Returns null if that failed. */
    fun commit(part: File): File? {
        val final = File(dir, part.name.removeSuffix(".part"))
        return if (part.renameTo(final)) final else null
    }

    fun discard(file: File) { file.delete() }

    /** Deletes leftover part files (e.g. after a crash) except the one currently being written. */
    fun purgeStale(active: File?) {
        dir.listFiles { f -> f.name.endsWith(".part") && f.absolutePath != active?.absolutePath }
            ?.forEach { it.delete() }
    }

    fun list(active: File?): List<Recording> {
        purgeStale(active)
        return dir.listFiles { f -> f.isFile && f.extension == "m4a" }
            ?.sortedByDescending { it.lastModified() }
            ?.map { Recording(it.name, it.absolutePath, it.length(), it.lastModified()) }
            ?: emptyList()
    }

    /** Refuses names that point outside the recordings directory. */
    fun delete(name: String): Boolean {
        val f = File(dir, name)
        return f.canonicalFile.parentFile == dir.canonicalFile && f.isFile && f.delete()
    }
}
