package com.kos.notifycontrol.domain.model

/** Result of a real system read. Never holds a placeholder value. */
sealed interface Reading<out T> {
    data object Loading : Reading<Nothing>
    data class Available<T>(val value: T) : Reading<T>
    data object Unavailable : Reading<Nothing>
}
