package com.kos.notifycontrol.features.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.BatteryState
import com.kos.notifycontrol.domain.model.DeviceInfo
import com.kos.notifycontrol.domain.model.Reading
import com.kos.notifycontrol.domain.model.StorageState
import com.kos.notifycontrol.domain.repository.BatteryRepository
import com.kos.notifycontrol.domain.repository.ClockRepository
import com.kos.notifycontrol.domain.repository.DeviceInfoRepository
import com.kos.notifycontrol.domain.repository.StorageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.ZonedDateTime
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class DashboardViewModel @Inject constructor(
    clock: ClockRepository,
    battery: BatteryRepository,
    private val storageRepo: StorageRepository,
    deviceRepo: DeviceInfoRepository
) : ViewModel() {

    /** null until the first real value arrives; the UI never shows a made-up value. */
    val now: StateFlow<ZonedDateTime?> =
        clock.now.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val battery: StateFlow<BatteryState?> =
        battery.state.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _storage = MutableStateFlow<Reading<StorageState>>(Reading.Loading)
    val storage: StateFlow<Reading<StorageState>> = _storage.asStateFlow()

    val deviceInfo: DeviceInfo = deviceRepo.read()

    /** Storage changes slowly: read on demand (screen resume), not on a timer. */
    fun refreshStorage() {
        viewModelScope.launch {
            val result = storageRepo.read()
            _storage.value = if (result != null) Reading.Available(result) else Reading.Unavailable
        }
    }
}
