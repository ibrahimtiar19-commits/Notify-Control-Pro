package com.kos.notifycontrol.features.network

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.NetworkSnapshot
import com.kos.notifycontrol.domain.repository.NetworkRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class NetworkUiState(val snapshot: NetworkSnapshot, val error: ActionError? = null)

@HiltViewModel
class NetworkViewModel @Inject constructor(private val repo: NetworkRepository) : ViewModel() {
    private val _state = MutableStateFlow(NetworkUiState(repo.read()))
    val state: StateFlow<NetworkUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { repo.changes.collect { refresh() } }
    }

    fun refresh() { _state.value = _state.value.copy(snapshot = repo.read()) }

    fun clearError() { _state.value = _state.value.copy(error = null) }

    /** After the BLUETOOTH_CONNECT dialog: always re-read the real state from the system. */
    fun onBluetoothPermissionResult(granted: Boolean) {
        _state.value = NetworkUiState(repo.read(), if (granted) null else ActionError.PERMISSION_REQUIRED)
    }

    fun onBluetoothPermissionDenied() = onBluetoothPermissionResult(false)
}
