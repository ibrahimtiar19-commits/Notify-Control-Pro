package com.kos.notifycontrol

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestCoroutineScheduler
import kotlinx.coroutines.test.TestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.rules.TestWatcher
import org.junit.runner.Description

/**
 * Sets Dispatchers.Main to a test dispatcher built on an explicit [scheduler].
 * Applied before runTest, runTest picks up this same scheduler from Dispatchers.Main,
 * so Main-dispatched work and the test body share one virtual clock (verified by DispatcherSetupTest).
 */
@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule(
    val scheduler: TestCoroutineScheduler = TestCoroutineScheduler()
) : TestWatcher() {
    val dispatcher: TestDispatcher = UnconfinedTestDispatcher(scheduler)
    override fun starting(description: Description) = Dispatchers.setMain(dispatcher)
    override fun finished(description: Description) = Dispatchers.resetMain()
}
