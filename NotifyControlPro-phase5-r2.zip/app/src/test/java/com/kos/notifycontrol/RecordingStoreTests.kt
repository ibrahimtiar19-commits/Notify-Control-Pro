package com.kos.notifycontrol

import com.kos.notifycontrol.data.system.RecordingStore
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class RecordingStoreTests {
    @get:Rule val tmp = TemporaryFolder()

    private fun store() = RecordingStore(File(tmp.root, "recordings"))

    @Test fun partFileIsNotListedUntilCommitted() {
        val s = store()
        val part = s.newPartFile("20261124_100000")
        part.writeText("audio")
        assertTrue(s.list(active = part).isEmpty())
        val final = s.commit(part)!!
        assertEquals("rec_20261124_100000.m4a", final.name)
        assertFalse(part.exists())
        assertEquals(listOf("rec_20261124_100000.m4a"), s.list(null).map { it.name })
        assertEquals(5L, s.list(null).first().sizeBytes)
    }

    @Test fun discardRemovesTheFile() {
        val s = store()
        val part = s.newPartFile("a"); part.writeText("x")
        s.discard(part)
        assertFalse(part.exists())
    }

    @Test fun stalePartsArePurgedButTheActiveOneIsKept() {
        val s = store()
        val stale = s.newPartFile("old"); stale.writeText("x")
        val active = s.newPartFile("now"); active.writeText("y")
        s.list(active = active)
        assertFalse(stale.exists())
        assertTrue(active.exists())
        s.list(active = null)
        assertFalse(active.exists())
    }

    @Test fun listIsNewestFirst() {
        val s = store()
        val a = s.commit(s.newPartFile("a").also { it.writeText("1") })!!
        val b = s.commit(s.newPartFile("b").also { it.writeText("2") })!!
        a.setLastModified(1_000_000L)
        b.setLastModified(2_000_000L)
        assertEquals(listOf(b.name, a.name), s.list(null).map { it.name })
    }

    @Test fun deleteRemovesOnlyFilesInsideTheDirectory() {
        val s = store()
        val rec = s.commit(s.newPartFile("a").also { it.writeText("1") })!!
        val outside = File(tmp.root, "secret.m4a").apply { writeText("keep") }
        assertFalse(s.delete("../secret.m4a"))
        assertTrue(outside.exists())
        assertFalse(s.delete("missing.m4a"))
        assertTrue(s.delete(rec.name))
        assertTrue(s.list(null).isEmpty())
    }
}
