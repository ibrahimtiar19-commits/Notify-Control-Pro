package com.kos.notifycontrol

import android.bluetooth.BluetoothAdapter
import android.net.wifi.WifiManager
import com.kos.notifycontrol.data.system.NetworkMappers
import com.kos.notifycontrol.domain.model.*
import com.kos.notifycontrol.domain.repository.NetworkRepository
import com.kos.notifycontrol.features.network.NetworkViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

private class FakeNetwork(var snap: NetworkSnapshot) : NetworkRepository {
    val events = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    override fun read() = snap
    override val changes: Flow<Unit> = events
}

private fun snap(wifi: ToggleState? = ToggleState.ON, bluetooth: ToggleState? = ToggleState.OFF) =
    NetworkSnapshot(wifi, bluetooth, false, ActiveTransport.WIFI, true)

class NetworkTests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun wifiMapping() {
        assertEquals(ToggleState.ON, NetworkMappers.wifi(WifiManager.WIFI_STATE_ENABLED))
        assertEquals(ToggleState.OFF, NetworkMappers.wifi(WifiManager.WIFI_STATE_DISABLED))
        assertEquals(ToggleState.TURNING_ON, NetworkMappers.wifi(WifiManager.WIFI_STATE_ENABLING))
        assertEquals(ToggleState.TURNING_OFF, NetworkMappers.wifi(WifiManager.WIFI_STATE_DISABLING))
        assertEquals(ToggleState.UNKNOWN, NetworkMappers.wifi(WifiManager.WIFI_STATE_UNKNOWN))
    }

    @Test fun bluetoothMapping() {
        assertEquals(ToggleState.ON, NetworkMappers.bluetooth(BluetoothAdapter.STATE_ON))
        assertEquals(ToggleState.OFF, NetworkMappers.bluetooth(BluetoothAdapter.STATE_OFF))
        assertEquals(ToggleState.TURNING_ON, NetworkMappers.bluetooth(BluetoothAdapter.STATE_TURNING_ON))
        assertEquals(ToggleState.TURNING_OFF, NetworkMappers.bluetooth(BluetoothAdapter.STATE_TURNING_OFF))
        assertEquals(ToggleState.UNKNOWN, NetworkMappers.bluetooth(-5))
    }

    @Test fun transportPriorityAndNone() {
        assertEquals(ActiveTransport.NONE, NetworkMappers.transport(false, true, true, true))
        assertEquals(ActiveTransport.WIFI, NetworkMappers.transport(true, true, true, false))
        assertEquals(ActiveTransport.CELLULAR, NetworkMappers.transport(true, false, true, false))
        assertEquals(ActiveTransport.ETHERNET, NetworkMappers.transport(true, false, false, true))
        assertEquals(ActiveTransport.OTHER, NetworkMappers.transport(true, false, false, false))
    }

    @Test fun airplaneReadsOnlyZeroOrOne() {
        assertEquals(true, NetworkMappers.airplane(1))
        assertEquals(false, NetworkMappers.airplane(0))
        assertNull(NetworkMappers.airplane(-1))
    }

    @Test fun viewModelRefreshesWhenSystemChanges() {
        val repo = FakeNetwork(snap(ToggleState.ON))
        val vm = NetworkViewModel(repo)
        assertEquals(ToggleState.ON, vm.state.value.snapshot.wifi)
        repo.snap = snap(ToggleState.OFF)
        repo.events.tryEmit(Unit)
        assertEquals(ToggleState.OFF, vm.state.value.snapshot.wifi)
    }

    @Test fun unsupportedHardwareStaysNull() {
        val vm = NetworkViewModel(FakeNetwork(snap(wifi = null)))
        assertNull(vm.state.value.snapshot.wifi)
    }

    @Test fun bluetoothPermissionDeniedSetsAndClearsError() {
        val vm = NetworkViewModel(FakeNetwork(snap()))
        vm.onBluetoothPermissionDenied()
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
        vm.clearError()
        assertNull(vm.state.value.error)
    }

    @Test fun bluetoothPermissionGrantedRereadsRealState() {
        val repo = FakeNetwork(snap(bluetooth = ToggleState.PERMISSION_REQUIRED))
        val vm = NetworkViewModel(repo)
        assertEquals(ToggleState.PERMISSION_REQUIRED, vm.state.value.snapshot.bluetooth)
        repo.snap = snap(bluetooth = ToggleState.ON) // what the system reports once the permission is granted
        vm.onBluetoothPermissionResult(true)
        assertEquals(ToggleState.ON, vm.state.value.snapshot.bluetooth)
        assertNull(vm.state.value.error)
    }

    @Test fun bluetoothPermissionDeniedKeepsPermissionRequiredAndReportsError() {
        val vm = NetworkViewModel(FakeNetwork(snap(bluetooth = ToggleState.PERMISSION_REQUIRED)))
        vm.onBluetoothPermissionResult(false)
        assertEquals(ToggleState.PERMISSION_REQUIRED, vm.state.value.snapshot.bluetooth)
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
    }

    @Test fun unreadableNetworkIsNotReportedAsNoConnection() {
        val unreadable = snap().copy(transport = ActiveTransport.UNKNOWN, internetValidated = false)
        val vm = NetworkViewModel(FakeNetwork(unreadable))
        assertEquals(ActiveTransport.UNKNOWN, vm.state.value.snapshot.transport)
        assertNotEquals(ActiveTransport.NONE, vm.state.value.snapshot.transport)
    }
}
