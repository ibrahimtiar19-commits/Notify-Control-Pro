package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.BatteryState
import com.kos.notifycontrol.domain.model.ChargingStatus
import com.kos.notifycontrol.domain.model.DeviceInfo
import com.kos.notifycontrol.domain.model.Reading
import com.kos.notifycontrol.domain.model.StorageState
import com.kos.notifycontrol.domain.model.ThemeMode
import com.kos.notifycontrol.domain.repository.BatteryRepository
import com.kos.notifycontrol.domain.repository.ClockRepository
import com.kos.notifycontrol.domain.repository.DeviceInfoRepository
import com.kos.notifycontrol.domain.repository.SettingsRepository
import com.kos.notifycontrol.domain.repository.StorageRepository
import com.kos.notifycontrol.features.dashboard.DashboardViewModel
import com.kos.notifycontrol.features.settings.SettingsViewModel
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test

private class FakeSettings : SettingsRepository {
    val state = MutableStateFlow(ThemeMode.SYSTEM)
    override val themeMode: Flow<ThemeMode> = state
    override suspend fun setThemeMode(mode: ThemeMode) { state.value = mode }
}

private class FakeClock(initial: ZonedDateTime?) : ClockRepository {
    val state = MutableStateFlow(initial)
    override val now: Flow<ZonedDateTime> = flow { state.collect { if (it != null) emit(it) } }
}

private class FakeBattery(initial: BatteryState?) : BatteryRepository {
    val s = MutableStateFlow(initial)
    override val state: Flow<BatteryState> = flow { s.collect { if (it != null) emit(it) } }
}

private class FakeStorage(var result: StorageState?) : StorageRepository {
    override suspend fun read(): StorageState? = result
}

private class FakeDevice(private val info: DeviceInfo) : DeviceInfoRepository {
    override fun read() = info
}

private val device = DeviceInfo("Acme", "X1", "15", 35)

private fun vm(
    clock: ClockRepository = FakeClock(null),
    battery: BatteryRepository = FakeBattery(null),
    storage: StorageRepository = FakeStorage(null)
) = DashboardViewModel(clock, battery, storage, FakeDevice(device))

@OptIn(ExperimentalCoroutinesApi::class)
class ViewModelTests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun settingsViewModelStartsWithStoredTheme() {
        val repo = FakeSettings().apply { state.value = ThemeMode.LIGHT }
        assertEquals(ThemeMode.LIGHT, SettingsViewModel(repo).themeMode.value)
    }

    @Test fun settingsViewModelWritesSelectedTheme() = runTest {
        val repo = FakeSettings()
        val vm = SettingsViewModel(repo)
        vm.setTheme(ThemeMode.DARK)
        assertEquals(ThemeMode.DARK, repo.state.value)
        assertEquals(ThemeMode.DARK, vm.themeMode.value)
    }

    @Test fun dashboardIsNullBeforeAnyRealValue() = runTest {
        val vm = vm()
        backgroundScope.launch { vm.now.collect {} }
        backgroundScope.launch { vm.battery.collect {} }
        runCurrent()
        assertNull(vm.now.value)
        assertNull(vm.battery.value)
    }

    @Test fun dashboardExposesClockValue() = runTest {
        val t = ZonedDateTime.of(2026, 11, 23, 10, 5, 0, 0, ZoneId.of("UTC"))
        val vm = vm(clock = FakeClock(t))
        backgroundScope.launch { vm.now.collect {} }
        runCurrent()
        assertEquals(t, vm.now.value)
    }

    @Test fun dashboardExposesBatteryState() = runTest {
        val b = BatteryState(80, ChargingStatus.CHARGING, null)
        val vm = vm(battery = FakeBattery(b))
        backgroundScope.launch { vm.battery.collect {} }
        runCurrent()
        assertEquals(b, vm.battery.value)
    }

    @Test fun storageStartsLoadingThenAvailable() = runTest {
        val s = StorageState(1000, 400)
        val vm = vm(storage = FakeStorage(s))
        assertEquals(Reading.Loading, vm.storage.value)
        vm.refreshStorage()
        runCurrent()
        assertEquals(Reading.Available(s), vm.storage.value)
    }

    @Test fun storageUnavailableWhenSystemReturnsNothing() = runTest {
        val vm = vm(storage = FakeStorage(null))
        vm.refreshStorage()
        runCurrent()
        assertEquals(Reading.Unavailable, vm.storage.value)
    }

    @Test fun deviceInfoComesFromRepository() {
        assertEquals(device, vm().deviceInfo)
    }
}
