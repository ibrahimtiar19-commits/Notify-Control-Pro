package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.*
import com.kos.notifycontrol.domain.repository.DisplayRepository
import com.kos.notifycontrol.domain.repository.SoundRepository
import com.kos.notifycontrol.features.display.DisplayViewModel
import com.kos.notifycontrol.features.sound.SoundViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

private fun display(brightness: Int? = 100, canWrite: Boolean = true) =
    DisplaySnapshot(brightness, false, canWrite, 30000, true, 1.0f, false)

private class FakeDisplay(var snap: DisplaySnapshot, var result: ActionResult? = null) : DisplayRepository {
    var setCalls = 0
    override fun read() = snap
    override val changes: Flow<Unit> = emptyFlow()
    override fun setBrightness(raw: Int): ActionResult {
        setCalls++
        val r = result ?: ActionResult.Success(raw)
        if (r is ActionResult.Success) snap = snap.copy(brightness = raw)
        return r
    }
}

private class FakeSound(var snap: SoundSnapshot, var result: ActionResult? = null) : SoundRepository {
    override fun read() = snap
    override val changes: Flow<Unit> = emptyFlow()
    override fun setVolume(stream: VolumeStream, level: Int): ActionResult {
        val r = result ?: ActionResult.Success(level)
        if (r is ActionResult.Success) snap = snap.copy(volumes = snap.volumes.map {
            if (it.stream == stream) it.copy(current = level) else it
        })
        return r
    }
    override fun setDnd(on: Boolean): ActionResult =
        result ?: ActionResult.Success(if (on) 1 else 0)
}

private val media = VolumeState(VolumeStream.MEDIA, 5, 0, 15)
private fun sound() = SoundSnapshot(listOf(media), RingerMode.NORMAL, DndState(PolicyAccess.GRANTED, DndFilter.ALL))

class ControlViewModelTests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun brightnessWithoutPermissionNeverCallsSystem() {
        val repo = FakeDisplay(display(canWrite = false))
        val vm = DisplayViewModel(repo)
        vm.setBrightness(200)
        assertEquals(0, repo.setCalls)
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
        assertEquals(100, vm.state.value.snapshot.brightness)
    }

    @Test fun brightnessSuccessShowsReReadValue() {
        val repo = FakeDisplay(display())
        val vm = DisplayViewModel(repo)
        vm.setBrightness(200)
        assertNull(vm.state.value.error)
        assertEquals(200, vm.state.value.snapshot.brightness)
    }

    @Test fun brightnessFailureKeepsRealValueAndReportsError() {
        val repo = FakeDisplay(display(), ActionResult.Failure(ActionError.FAILED))
        val vm = DisplayViewModel(repo)
        vm.setBrightness(200)
        assertEquals(ActionError.FAILED, vm.state.value.error)
        assertEquals(100, vm.state.value.snapshot.brightness)
        vm.clearError()
        assertNull(vm.state.value.error)
    }

    @Test fun volumeSuccessUpdatesFromSystemRead() {
        val vm = SoundViewModel(FakeSound(sound()))
        vm.setVolume(VolumeStream.MEDIA, 9)
        assertNull(vm.state.value.error)
        assertEquals(9, vm.state.value.snapshot.volumes.first().current)
    }

    @Test fun volumeFailureKeepsRealValue() {
        val vm = SoundViewModel(FakeSound(sound(), ActionResult.Failure(ActionError.PERMISSION_REQUIRED)))
        vm.setVolume(VolumeStream.MEDIA, 9)
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
        assertEquals(5, vm.state.value.snapshot.volumes.first().current)
    }

    @Test fun dndFailureWithoutAccessReportsPermission() {
        val vm = SoundViewModel(FakeSound(sound(), ActionResult.Failure(ActionError.PERMISSION_REQUIRED)))
        vm.setDnd(true)
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
    }

    @Test fun volumeFractionUsesRealRange() {
        assertEquals(0.5f, VolumeState(VolumeStream.CALL, 3, 1, 5).fraction, 0.0001f)
        assertFalse(VolumeState(VolumeStream.MEDIA, 0, 0, 0).canAdjust)
        assertEquals(0f, VolumeState(VolumeStream.MEDIA, 0, 0, 0).fraction, 0f)
    }

    @Test fun dndIsOnForAnyRestrictiveFilter() {
        assertFalse(DndState(PolicyAccess.GRANTED, DndFilter.ALL).isOn)
        assertFalse(DndState(PolicyAccess.GRANTED, DndFilter.UNKNOWN).isOn)
        assertTrue(DndState(PolicyAccess.GRANTED, DndFilter.PRIORITY).isOn)
        assertTrue(DndState(PolicyAccess.NOT_GRANTED, DndFilter.NONE).isOn)
    }
}
