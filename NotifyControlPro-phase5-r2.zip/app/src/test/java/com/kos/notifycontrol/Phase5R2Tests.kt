package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.*
import com.kos.notifycontrol.domain.repository.FlashlightRepository
import com.kos.notifycontrol.domain.repository.SoundRepository
import com.kos.notifycontrol.domain.repository.TimerRepository
import com.kos.notifycontrol.domain.tools.TimerLogic
import com.kos.notifycontrol.features.sound.SoundViewModel
import com.kos.notifycontrol.features.tools.FlashlightViewModel
import com.kos.notifycontrol.features.tools.TimerViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

private class R2Sound(var snap: SoundSnapshot, var result: ActionResult? = null) : SoundRepository {
    override fun read() = snap
    override val changes: Flow<Unit> = emptyFlow()
    override fun setVolume(stream: VolumeStream, level: Int): ActionResult = result ?: ActionResult.Success(level)
    override fun setDnd(on: Boolean): ActionResult = result ?: ActionResult.Success(if (on) 1 else 0)
}

private class R2Flash : FlashlightRepository {
    val s = MutableStateFlow(FlashlightState.OFF)
    override val state: Flow<FlashlightState> = s
    override fun setTorch(on: Boolean): ActionResult = ActionResult.Success(0)
}

private class R2Timer : TimerRepository {
    var restored = 0
    val end = MutableStateFlow<Long?>(null)
    override val endAtMillis: Flow<Long?> = end
    override suspend fun start(durationMs: Long): ActionResult = ActionResult.Success(0)
    override suspend fun cancel() {}
    override suspend fun restore() { restored++ }
}

private fun soundWith(access: PolicyAccess) =
    SoundSnapshot(emptyList(), RingerMode.NORMAL, DndState(access, DndFilter.ALL))

@OptIn(ExperimentalCoroutinesApi::class)
class Phase5R2Tests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun dndAccessUnknownIsNotFoldedIntoNotGranted() {
        val vm = SoundViewModel(R2Sound(soundWith(PolicyAccess.UNKNOWN)))
        val dnd = vm.state.value.snapshot.dnd
        assertEquals(PolicyAccess.UNKNOWN, dnd.access)
        assertNotEquals(PolicyAccess.NOT_GRANTED, dnd.access)
        assertFalse(dnd.canToggle)
    }

    @Test fun dndCanToggleOnlyWhenAccessIsGranted() {
        assertTrue(DndState(PolicyAccess.GRANTED, DndFilter.ALL).canToggle)
        assertFalse(DndState(PolicyAccess.NOT_GRANTED, DndFilter.ALL).canToggle)
        assertFalse(DndState(PolicyAccess.UNKNOWN, DndFilter.PRIORITY).canToggle)
    }

    @Test fun dndRefreshPicksUpAccessChangeFromSystem() {
        val repo = R2Sound(soundWith(PolicyAccess.NOT_GRANTED))
        val vm = SoundViewModel(repo)
        repo.snap = soundWith(PolicyAccess.GRANTED) // user granted it in system settings
        vm.refresh()
        assertEquals(PolicyAccess.GRANTED, vm.state.value.snapshot.dnd.access)
    }

    @Test fun dndToggleFailureIsReportedWhenAccessUnknown() {
        val vm = SoundViewModel(R2Sound(soundWith(PolicyAccess.UNKNOWN), ActionResult.Failure(ActionError.PERMISSION_REQUIRED)))
        vm.setDnd(true)
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
    }

    @Test fun flashlightUnknownIsPassedThroughNotShownAsOff() = runTest {
        val repo = R2Flash()
        val vm = FlashlightViewModel(repo)
        backgroundScope.launch { vm.state.collect {} }
        runCurrent()
        repo.s.value = FlashlightState.UNKNOWN
        runCurrent()
        assertEquals(FlashlightState.UNKNOWN, vm.state.value)
        assertNotEquals(FlashlightState.OFF, vm.state.value)
    }

    @Test fun timerViewModelRestoresSavedTimerOnCreation() {
        val repo = R2Timer()
        TimerViewModel(repo)
        assertEquals(1, repo.restored)
    }

    @Test fun notificationsAllowedRules() {
        assertTrue(TimerLogic.notificationsAllowed(30, true, false))   // pre-13: no runtime permission needed
        assertFalse(TimerLogic.notificationsAllowed(30, false, true))  // notifications disabled in system settings
        assertFalse(TimerLogic.notificationsAllowed(33, true, false))  // 13+: permission denied
        assertTrue(TimerLogic.notificationsAllowed(33, true, true))
        assertFalse(TimerLogic.notificationsAllowed(34, false, true))
    }
}
