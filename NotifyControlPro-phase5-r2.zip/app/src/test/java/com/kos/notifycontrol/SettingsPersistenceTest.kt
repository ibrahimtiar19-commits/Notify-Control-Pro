package com.kos.notifycontrol

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.kos.notifycontrol.data.preferences.DataStoreSettingsRepository
import com.kos.notifycontrol.domain.model.ThemeMode
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class SettingsPersistenceTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun repo(file: File, scope: CoroutineScope) =
        DataStoreSettingsRepository(PreferenceDataStoreFactory.create(scope = scope) { file })

    @Test fun defaultIsSystemWhenNothingStored() = runTest {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val r = repo(File(tmp.root, "a.preferences_pb"), scope)
        assertEquals(ThemeMode.SYSTEM, r.themeMode.first())
        scope.coroutineContext.job.cancelAndJoin()
    }

    @Test fun savedThemeSurvivesRecreatingTheStore() = runTest {
        val file = File(tmp.root, "b.preferences_pb")
        val scope1 = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        repo(file, scope1).setThemeMode(ThemeMode.DARK)
        scope1.coroutineContext.job.cancelAndJoin() // closes the store (waits for completion) before opening a second one on the same file
        val scope2 = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        assertEquals(ThemeMode.DARK, repo(file, scope2).themeMode.first())
        scope2.coroutineContext.job.cancelAndJoin()
    }
}
